# AI-Integrated Smart Helmet System: Rider Fatigue Detection & Environmental Context Pipeline

An edge-compatible machine learning pipeline for real-time rider cognitive state estimation using **MPU6050 6-DoF inertial sensing** and **Sensirion SPS30 particulate matter exposure sensing**.

---

> [!WARNING]
> **SCIENTIFIC & MEDICAL DISCLAIMER:**
> This system is **NOT** a certified medical diagnostic device. It is an algorithmic prototyping framework designed for research, embedded proof-of-concept testing, and machine-learning pipeline development. The SPS30 particulate matter sensor is an **environmental/contextual sensor**, not a direct biological or physiological detector of fatigue. Synthetic datasets are purely simulated for algorithm development and must **not** be cited or treated as real-world clinical/experimental data.

---

## Table of Contents
1. [Project Objective](#1-project-objective)
2. [Sensor Architecture & Physical Principles](#2-sensor-architecture--physical-principles)
3. [Dataset Schema & Feature Definitions](#3-dataset-schema--feature-definitions)
4. [Synthetic Data Generation Methodology](#4-synthetic-data-generation-methodology)
5. [The Research Hypothesis: Role of SPS30 Particulate Matter](#5-the-research-hypothesis-role-of-sps30-particulate-matter)
6. [Quickstart Guide](#6-quickstart-guide)
   - [Step 1: Generating the Dataset](#step-1-generating-the-dataset)
   - [Step 2: Training & Evaluating Models](#step-2-training--evaluating-models)
   - [Step 3: Running Real-Time Inference](#step-3-running-real-time-inference)
7. [Experimental Results & Model Evaluation](#7-experimental-results--model-evaluation)
   - [Model A (Motion Only) vs. Model B (Motion + SPS30)](#model-a-vs-model-b)
   - [Feature Importance Analysis](#feature-importance-analysis)
8. [Limitations of Synthetic Data](#8-limitations-of-synthetic-data)
9. [Edge Deployment: Connecting Real Raspberry Pi Sensors](#9-edge-deployment-connecting-real-raspberry-pi-sensors)

---

## 1. Project Objective

Motorcyclist fatigue and hypovigilance are major contributing factors to traffic accidents worldwide. This project develops an embedded edge AI classification pipeline that monitors a rider's state in real time:

- **Class `0`: `ALERT`** — Attentive posture, active mirror scanning, dynamic head movements, and prompt postural recovery.
- **Class `1`: `DROWSY`** — Staring/hypovigilance epochs, intermittent episodic head nodding with rapid startle/jerk recoveries.
- **Class `2`: `FATIGUED`** — Prolonged forward/lateral drooping postures, sluggish motor control, wandering yaw, and delayed recovery.

The core research question investigates:
> *"Can environmental particulate-matter exposure information improve multimodal rider fatigue-state classification when paired with head kinematics?"*

---

## 2. Sensor Architecture & Physical Principles

The Smart Helmet system integrates two complementary sensor modules:

### 1. InvenSense MPU6050 (6-DoF Inertial Measurement Unit)
Mounted rigidly to the helmet crown:
- **Triple-Axis Accelerometer ($a_x, a_y, a_z$)**: Measures linear and gravitational acceleration in $m/s^2$. Under resting upright conditions, static acceleration reflects earth gravity ($\approx 9.81 \, m/s^2$).
- **Triple-Axis Gyroscope ($g_x, g_y, g_z$)**: Measures angular velocity in degrees per second ($^\circ/s$). Captures head pitch velocity (nodding/dropping), roll velocity, and yaw turns (shoulder/mirror checks).

### 2. Sensirion SPS30 (Optical Particulate Matter Sensor)
Mounted on the exterior airflow channel with particulate sampling:
- **Mass Concentrations**: $PM_{1.0}, PM_{2.5}, PM_{4.0}, PM_{10}$ in $\mu g/m^3$.
- Measures micro-environmental exposure (urban clean air, moderate traffic, diesel exhaust, dust plumes, industrial smog).

---

## 3. Dataset Schema & Feature Definitions

The generated dataset (`data/smart_helmet_synthetic_10000.csv`) comprises exactly **10,000 rows** across 20 distinct subjects and 40 riding sessions:

| Column Name | Type | Unit / Range | Description |
|---|---|---|---|
| `session_id` | String | `SESS_01`–`SESS_40` | Unique identifier for the continuous recording session. |
| `subject_id` | String | `SUB_01`–`SUB_20` | Unique subject identifier with individual biomechanical profiles. |
| `timestamp` | String | `YYYY-MM-DD HH:MM:SS` | 1 Hz sequential sample timestamp. |
| `ax` | Float | $m/s^2$ | Longitudinal acceleration (pitch-dependent gravity projection + vibration). |
| `ay` | Float | $m/s^2$ | Lateral acceleration (roll-dependent gravity projection + road noise). |
| `az` | Float | $m/s^2$ | Vertical acceleration (upward vertical gravity projection). |
| `gx` | Float | $^\circ/s$ | Pitch rotational velocity (forward/backward nod rate). |
| `gy` | Float | $^\circ/s$ | Roll rotational velocity (lateral head tilt rate). |
| `gz` | Float | $^\circ/s$ | Yaw rotational velocity (left/right road scanning). |
| `tilt_angle` | Float | Degrees ($^\circ$) | Angle between the acceleration vector and vertical reference: $\arccos\left(\text{clip}\left(\frac{a_z}{\|a\|}, -1, 1\right)\right) \times \frac{180}{\pi}$. |
| `acc_magnitude` | Float | $m/s^2$ | Euclidean norm: $\sqrt{a_x^2 + a_y^2 + a_z^2} \approx 9.81 \, m/s^2$. |
| `gyro_magnitude` | Float | $^\circ/s$ | Euclidean norm of angular velocity: $\sqrt{g_x^2 + g_y^2 + g_z^2}$. |
| `pm1` | Float | $\mu g/m^3$ | SPS30 Particulate Matter $< 1.0 \, \mu m$. |
| `pm25` | Float | $\mu g/m^3$ | SPS30 Particulate Matter $< 2.5 \, \mu m$. |
| `pm4` | Float | $\mu g/m^3$ | SPS30 Particulate Matter $< 4.0 \, \mu m$. |
| `pm10` | Float | $\mu g/m^3$ | SPS30 Particulate Matter $< 10.0 \, \mu m$. |
| `pm25_change` | Float | $\mu g/m^3/s$ | Discrete first-difference: $PM_{2.5}(t) - PM_{2.5}(t-1)$ ($0.0$ at session start). |
| `pm10_change` | Float | $\mu g/m^3/s$ | Discrete first-difference: $PM_{10}(t) - PM_{10}(t-1)$ ($0.0$ at session start). |
| `environment` | Categorical | `CLEAN`, `MODERATE`, `POLLUTED`, `SPIKE` | Environmental classification based on particulate concentration and dynamic surges. |
| `fatigue_score` | Float | $[0.0, 1.0]$ | Latent continuous physiological fatigue trajectory. |
| `label` | Integer | `0`, `1`, `2` | Machine learning target class. |
| `label_name` | String | `ALERT`, `DROWSY`, `FATIGUED` | Human-readable target class name. |

---

## 4. Synthetic Data Generation Methodology

Synthetic sensor streams are generated through physical and behavioral modeling rather than naive independent Gaussian sampling:

1. **Temporal Coherence & Stochastic Kinematics**:
   - Angular orientations and rotational velocities are generated through an **Autoregressive AR(1)** damped process with time constants tailored to human head mass and neck biomechanics.
   - Micro-vibrations from vehicle engines and road roughness are superimposed onto gravitational projections.

2. **Non-Trivial Overlapping Classes**:
   - The generator explicitly enforces overlapping distributions. An **`ALERT`** rider checking mirrors or looking down at navigation instruments will exhibit brief tilts of $20^\circ$–$30^\circ$. A **`FATIGUED`** rider straightening up momentarily will exhibit an upright tilt of $10^\circ$–$15^\circ$.
   - This prevents trivial single-threshold decision boundaries.

3. **Physical Particulate Constraints**:
   - By aerosol physics, smaller fractions are subcomponents of larger fractions. The generator mathematically guarantees:
     $$PM_{1.0} \le PM_{2.5} \le PM_{4.0} \le PM_{10.0}$$
     with 100% compliance across all 10,000 samples.

4. **Multi-Subject Biomechanical Profiles**:
   - 20 distinct synthetic subjects are generated with individualized posture baselines (pitch/roll offsets), movement amplitudes, tremor scales, and recovery dynamics to prevent the model from memorizing single-person traits.

5. **Decoupled Environmental Co-factors**:
   - The air pollution level is simulated independently of the fatigue state. All 12 cross-combinations (e.g., `ALERT` in `POLLUTED` air, `FATIGUED` in `CLEAN` air) are explicitly present in significant quantities.

---

## 5. The Research Hypothesis: Role of SPS30 Particulate Matter

A common pitfall in multimodal sensor integration is assuming that adding sensor features automatically improves model accuracy.

### Key Hypothesis
Riding in heavy particulate pollution (high $PM_{2.5}$ and $PM_{10}$) may exacerbate eye irritation, respiratory discomfort, and cognitive fatigue over long durations. However, on instantaneous 1-second time windows:
- **Kinematic sensors (MPU6050)** capture direct physiological movement (nodding, drooping, sluggish recovery).
- **Particulate sensors (SPS30)** measure ambient air quality, which does **not** causally trigger instantaneous head nods.

By training two competing models—**Model A (Motion Only)** and **Model B (Motion + SPS30)**—the pipeline experimentally tests whether raw particulate features act as a predictive signal or introduce out-of-distribution noise when generalizing to unseen riding sessions.

---

## 6. Quickstart Guide

### Environment Setup
Install dependencies in your Python 3.9+ environment:
```bash
pip install -r requirements.txt
```

### Step 1: Generating the Dataset
Generate the 10,000-row synthetic dataset with automated quality checks:
```bash
python generate_dataset.py
```
*Output:*
- Validates 10 automated data-quality rules (row count, absence of NaNs, strict PM ordering, physical acceleration ranges, class distributions).
- Saves: `data/smart_helmet_synthetic_10000.csv`.

### Step 2: Training & Evaluating Models
Train Random Forest (Models A and B) and Logistic Regression baselines using session-grouped stratified splitting:
```bash
python train_model.py
```
*Output:*
- Prints complete classification reports, confusion matrices, and model comparison deltas.
- Saves plots:
  - `results/confusion_matrix_motion_only.png`
  - `results/confusion_matrix_motion_sps30.png`
  - `results/model_comparison.png`
  - `results/feature_importance.png`
- Saves serialized models:
  - `models/smart_helmet_random_forest.joblib`
  - `models/feature_names.json`
  - `models/scaler.joblib`

### Step 3: Running Real-Time Inference
Run single-sample or batch inference:
```bash
# Demonstration mode (evaluates test samples from CSV and simulates Raspberry Pi loop)
python predict.py

# Custom CLI sensor vector
python predict.py --ax -3.8 --ay 0.4 --az 9.1 --gx 1.2 --gy 0.5 --gz 0.9 --pm1 20 --pm25 32 --pm4 40 --pm10 50

# Specific dataset row index
python predict.py --row-idx 250
```

---

## 7. Experimental Results & Model Evaluation

### Data Splitting: Session-Grouped Stratified Split
To avoid temporal leakage (which happens when consecutive rows from the same time series are randomly split into train and test), data splitting is conducted at the **session level**:
- **Train Set (70%)**: 28 sessions (7,000 rows)
- **Validation Set (15%)**: 6 sessions (1,500 rows)
- **Test Set (15%)**: 6 sessions (1,500 rows)
Unseen test sessions contain riders and routes not encountered during training.

### Model Comparison Table (Test Set: 1,500 Unseen Samples)

| Model Architecture | Feature Set | Accuracy | Macro F1 | Weighted F1 | Macro Precision | Macro Recall |
|---|---|:---:|:---:|:---:|:---:|:---:|
| **Random Forest (Model A)** | **Motion Only (9 feats)** | **85.27%** | **0.8330** | **0.8516** | **0.8449** | **0.8263** |
| **Random Forest (Model B)** | **Motion + SPS30 (15 feats)** | **81.80%** | **0.8018** | **0.8174** | **0.8171** | **0.7933** |
| Logistic Regression (Model A) | Motion Only (9 feats, Scaled) | 81.13% | 0.7896 | 0.8096 | 0.8002 | 0.7844 |
| Logistic Regression (Model B) | Motion + SPS30 (15 feats, Scaled) | 81.00% | 0.7856 | 0.8084 | 0.8062 | 0.7766 |

### Empirical Findings: Motion Only vs. Motion + SPS30
- **Random Forest Model A (Motion Only)** achieved **85.27% accuracy** and a **Macro F1 of 0.8330**.
- **Random Forest Model B (Motion + SPS30)** achieved **81.80% accuracy** and a **Macro F1 of 0.8018** ($\Delta = -3.47\%$).

#### Why did adding SPS30 particulate features slightly lower accuracy?
Because particulate pollution was deliberately decoupled from instantaneous fatigue (as instructed to mirror reality), clean and polluted air occur across all fatigue states. In a pure decision tree classifier, conditioning instant head-nod predictions on raw ambient particulate levels introduces spurious correlation on the training sessions that does not generalize to new test routes. 

This confirms the scientific principle: **environmental sensors should provide contextual filtering or exposure aggregation over longer time windows rather than being fed as direct features for instantaneous micro-nod classification.**

### Feature Importance (Random Forest Model B)

The top 10 features extracted by Gini importance:
1. `ax` (0.2527) — *MPU6050 Motion (Forward gravitational pitch projection)*
2. `tilt_angle` (0.1976) — *MPU6050 Motion (Geometric head tilt from vertical)*
3. `az` (0.1055) — *MPU6050 Motion (Vertical gravitational vector)*
4. `pm25` (0.0797) — *SPS30 Environmental*
5. `gyro_magnitude` (0.0646) — *MPU6050 Motion (Dynamic rotational rate)*
6. `pm10` (0.0587) — *SPS30 Environmental*
7. `pm4` (0.0540) — *SPS30 Environmental*
8. `pm1` (0.0504) — *SPS30 Environmental*
9. `ay` (0.0271) — *MPU6050 Motion (Lateral tilt)*
10. `gy` (0.0245) — *MPU6050 Motion (Roll rate)*

> [!NOTE]
> High synthetic Gini importance on `pm25` indicates that decision trees split on particulate levels during training; however, cross-session generalization demonstrates that these splits represent session-specific variance rather than invariant fatigue markers.

---

## 8. Limitations of Synthetic Data

1. **Simulated Noise**: While road vibration and sensor jitter are modeled via Gaussian and autoregressive processes, real motorcycle riding introduces non-linear bumps, potholes, aerodynamic buffeting at high speeds, and engine harmonics.
2. **Simplified Helmet Fastening**: Real helmets shift on the rider's scalp depending on strap tightness, modifying the neutral calibration vector over time.
3. **Environmental Lag**: Real SPS30 sensors require fan stabilization and optical chamber purging, introducing response lags (typically 2–8 seconds) during sudden plume transitions.
4. **Behavioral Diversity**: Real riders exhibit personal quirks, such as singing, shoulder stretching, or head bobbing to music, which require extensive field calibration.

---

## 9. Edge Deployment: Dual-Layer Arduino + Raspberry Pi USB Architecture

In this system architecture:
1. **All physical sensors and actuators are wired to the Arduino Uno**:
   - MPU6050 (6-DoF Motion via I2C `A4/A5`)
   - SPS30 (Particulate Exposure via I2C `A4/A5`)
   - HC-SR04 (Rear Obstacle Radar on `D4/D5`)
   - NEO-6M (GPS Navigation on `D8/D9`)
   - MAX7219 (8x8 LED Matrix on `D2/D3/D6`)
   - DFPlayer Mini (Voice Navigation on `D10/D11`)
   - Central Buzzer on `D7`
2. **No sensors are connected directly to the Raspberry Pi GPIO**.
3. **The Raspberry Pi connects to the Arduino Uno via a standard USB cable** (USB Serial at 115200 baud).

```text
 ┌──────────────────────────────────────────────────────────────┐
 │                     ARDUINO UNO                              │
 │  All Sensors (MPU6050, SPS30, Radar, GPS) & Actuators        │
 │  LAYER 1: Threshold-based decision (18° Drowsy, 30° Fatigue) │
 └──────────────────────────────┬───────────────────────────────┘
                                │
          TELEM: ax,ay,az,gx,gy,gz,tilt,pm...,threshState
                                │ (USB Serial @ 115200 baud)
                                ▼
 ┌──────────────────────────────────────────────────────────────┐
 │                    RASPBERRY PI                              │
 │  Script: rpi_arduino_bridge.py                               │
 │  LAYER 2: Random Forest AI Classifier (predict_fatigue)      │
 └──────────────────────────────┬───────────────────────────────┘
                                │
                       AI: state,confidence
                                │ (USB Serial @ 115200 baud)
                                ▼
 ┌──────────────────────────────────────────────────────────────┐
 │                FINAL DECISION FUSION LAYER                   │
 │                (Embedded in Arduino Uno)                     │
 │  - Fuses Layer 1 + Layer 2                                   │
 │  - Drives MAX7219 matrix, Buzzer, and DFPlayer voice alerts  │
 │  - Automatic Layer 1 fallback if USB or Pi disconnects       │
 └──────────────────────────────────────────────────────────────┘
```

### Running the Complete System (Both AI Fatigue + GPS Navigation)

#### Mode A: Full Interactive Web HUD & Navigation Dashboard (Recommended)
This runs the dual-layer AI inference loop AND serves a real-time web dashboard with live Leaflet.js GPS mapping, turn-by-turn navigation alerts, and instant location search.

1. **On your Raspberry Pi** (or local laptop with Arduino connected):
   ```bash
   # Install edge dependencies
   pip install -r requirements_pi.txt

   # Start the Full Web HUD + GPS Dashboard
   python3 dashboard_server.py --host 0.0.0.0 --port 8080
   ```
2. **Open the Dashboard in your Browser**:
   - On the Pi itself: `http://localhost:8080`
   - From any phone, tablet, or laptop on the same Wi-Fi network: `http://<RASPBERRY_PI_IP>:8080`
3. **Using Location Search & Navigation**:
   - Type any destination into the search bar at the top (e.g., *"Connaught Place, New Delhi"* or *"Central Park, New York"*) and click **Navigate**.
   - Or click anywhere on the live OpenStreetMap to drop a destination pin.
   - The dashboard computes coordinates and sends `DEST:<lat>,<lon>` to the Arduino over USB serial.
   - The Arduino computes distance and bearing, displays directional arrows on the MAX7219 matrix, announces turns through DFPlayer Mini voice prompts, and updates the HUD in real time.

#### Mode B: Headless Terminal AI Bridge (+ GPS Telemetry)
If you only want a lightweight terminal stream without a web browser:
```bash
python3 rpi_arduino_bridge.py
```
This logs live telemetry lines with AI inference confidence and GPS fix status directly to the terminal.

#### Mode C: Offline Bench Simulation (No Physical Hardware Needed)
To test the entire web UI, live GPS movement, and AI model without connecting hardware:
```bash
python3 dashboard_server.py --simulate --host 0.0.0.0 --port 8080
```

---

## 10. Arduino Hardware Pinout Reference

| Component | Arduino Uno Pin | Protocol / Type | Function |
|---|---|---|---|
| **MPU6050** | `A4 (SDA)`, `A5 (SCL)` | I2C | 6-DoF Head Motion & Tilt Angle |
| **SPS30** | `A4 (SDA)`, `A5 (SCL)` | I2C | Optical Particulate Matter ($PM_{1.0}, PM_{2.5}, PM_4, PM_{10}$) |
| **NEO-6M GPS** | `D8 (TX->GPS RX)`, `D9 (RX<-GPS TX)` | SoftwareSerial (9600 baud) | Latitude, Longitude, Ground Speed, Satellites |
| **HC-SR04 Radar** | `D4 (Trigger)`, `D5 (Echo)` | Digital GPIO | Blind-Spot Rear Proximity Detection |
| **MAX7219 Matrix** | `D2 (DIN)`, `D3 (CLK)`, `D6 (CS)` | Digital Bitbang / SPI | 8x8 Visual Safety Alerts & Turn Arrows |
| **DFPlayer Mini** | `D10 (TX->DF RX)`, `D11 (RX<-DF TX)` | SoftwareSerial (9600 baud) | Voice Prompts & Navigation Guidance |
| **Central Buzzer** | `D7` | Digital PWM | High-Pitch Acoustic Warning Alarm |
| **Raspberry Pi** | USB Port (`/dev/ttyACM0` / `/dev/ttyUSB0`) | USB Serial (115200 baud) | Bidirectional Telemetry & AI Command Relay |


